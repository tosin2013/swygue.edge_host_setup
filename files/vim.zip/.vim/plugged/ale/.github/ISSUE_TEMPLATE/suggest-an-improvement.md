---
name: Suggest an improvement
labels: enhancement
about: Suggest some way to improve ALE, or add a new feature.

---

<!-- There's no fixed format for feature requests. Just add your thoughts. -->
