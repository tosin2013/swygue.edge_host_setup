package problems

func bar() {}
