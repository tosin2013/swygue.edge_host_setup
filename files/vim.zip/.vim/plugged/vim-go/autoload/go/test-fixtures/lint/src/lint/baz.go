package lint

func baz() {}
